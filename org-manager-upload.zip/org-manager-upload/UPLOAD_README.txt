ORG MANAGER — Upload these files only

1) index.html
2) manifest.json
3) sw.js
4) icon-192.png
5) icon-512.png

Firebase:
- Authentication → Email/Password → Enable
- Firestore Rules → Publish:

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /orgs/{orgId} {
      allow read, write: if request.auth != null && request.auth.uid == orgId;
    }
    match /orgs/{orgId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == orgId;
    }
  }
}

Master admin: index.html me MASTER_EMAILS me apna email daalo.

Optional: apna Firebase config index.html me firebase.initializeApp({...}) replace karo.
